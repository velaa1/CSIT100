**Task 1**: Modify **shuffle.py** to correct the error.
