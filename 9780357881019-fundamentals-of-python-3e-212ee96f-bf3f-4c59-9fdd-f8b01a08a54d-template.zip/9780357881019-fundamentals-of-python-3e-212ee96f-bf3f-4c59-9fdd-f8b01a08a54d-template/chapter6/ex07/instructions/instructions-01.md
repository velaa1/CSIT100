**Task 1**: Define the `inputFloat` function.
