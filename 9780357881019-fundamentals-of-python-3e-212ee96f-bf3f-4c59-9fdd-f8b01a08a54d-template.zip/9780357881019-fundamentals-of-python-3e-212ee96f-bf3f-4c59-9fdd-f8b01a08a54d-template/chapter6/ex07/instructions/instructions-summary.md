## Your Tasks

Add a function named `inputFloat` to the module `testinputfunctions` (available in the file named **testinputfunctions.py**. This function behaves like the function `inputInt` developed in this chapter but provides for the robust input of floating-point numbers. This function allows digits only or digits and a single decimal point in the input string. Test your new function in this module. (LO: 6.2)

## Instructions
