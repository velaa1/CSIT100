**Task 1**: Define the `limitReached` function.
