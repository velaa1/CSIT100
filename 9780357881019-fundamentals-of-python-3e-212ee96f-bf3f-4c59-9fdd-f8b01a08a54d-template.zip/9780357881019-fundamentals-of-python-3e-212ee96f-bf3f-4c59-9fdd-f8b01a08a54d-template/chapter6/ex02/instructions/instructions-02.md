**Task 2**: Define the `improveEstimate` function.
