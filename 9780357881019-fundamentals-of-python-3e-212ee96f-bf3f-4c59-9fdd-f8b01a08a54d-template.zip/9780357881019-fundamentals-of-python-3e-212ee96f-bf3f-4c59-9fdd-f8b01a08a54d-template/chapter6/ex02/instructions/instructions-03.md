**Task 3**: The `newton` method returns an estimate.
