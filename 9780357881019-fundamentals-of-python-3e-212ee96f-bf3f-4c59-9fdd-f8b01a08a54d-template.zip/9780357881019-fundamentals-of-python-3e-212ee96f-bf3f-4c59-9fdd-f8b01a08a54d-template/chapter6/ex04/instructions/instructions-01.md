**Task 1**: Modify the **recognizer.py** program so that it recognizes the additional types of variations.
