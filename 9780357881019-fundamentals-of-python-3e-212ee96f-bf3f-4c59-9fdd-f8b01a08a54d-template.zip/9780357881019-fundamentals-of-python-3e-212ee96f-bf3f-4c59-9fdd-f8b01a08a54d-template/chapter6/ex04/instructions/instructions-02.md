An example of the program is shown below:

```txt
Enter a sentence or press return to quit: The boy saw the girl
Ok, grammatically correct
Enter a sentence or press return to quit: The girl hit the red ball with a bat
Ok, grammatically correct
Enter a sentence or press return to quit: The boy saw the girl and the girl hit the red ball with a bat
Ok, grammatically correct
Enter a sentence or press return to quit:
```
