An example of the program is shown below:

```txt
1 Open
2 Save
3 Compile
4 Run
5 Quit
Enter a number: 2
Command = Save
1 Open
2 Save
3 Compile
4 Run
5 Quit
Enter a number: 3
Command = Compile
1 Open
2 Save
3 Compile
4 Run
5 Quit
Enter a number: 5
Command = Quit
Have a nice day!
```
