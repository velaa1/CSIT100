**Task 1**: Design and implement a program that uses a simple text-based command interpreter.
