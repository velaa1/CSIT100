**Task 1**: Define the `isSorted` predicate.
