**Task 2**: The program also includes a `main` function that allows the user to compute square roots of inputs until the enter/return key is pressed.
