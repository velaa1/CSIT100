**Task 1**: Define the `newton` function.
