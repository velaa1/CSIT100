An example of the program is shown below:

```txt
Enter a positive number or enter/return to quit: 2
The program's estimate is 1.4142135623746899
Python's estimate is      1.4142135623730951
Enter a positive number or enter/return to quit: 4
The program's estimate is 2.0000000929222947
Python's estimate is      2.0
Enter a positive number or enter/return to quit: 9
The program's estimate is 3.000000001396984
Python's estimate is      3.0
Enter a positive number or enter/return to quit:
```
