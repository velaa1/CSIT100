## Your Tasks

Package Newton’s method for approximating square roots (_Case Study 3-2_) in a function named `newton`. This function expects the input number as an argument and returns the estimate of its square root. The script in the file named **newton.py** should also include a `main` function that allows the user to compute square roots of inputs until she presses the enter/return key. (LO: 6.2)

## Instructions
