**Task 1**: Define the `myRange` function.
