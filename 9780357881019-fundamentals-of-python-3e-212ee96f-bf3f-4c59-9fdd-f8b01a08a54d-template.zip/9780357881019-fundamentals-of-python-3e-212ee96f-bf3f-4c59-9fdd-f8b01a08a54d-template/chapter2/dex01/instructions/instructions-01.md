**Task 1**: Modify **salestax.py** to correct the error.
