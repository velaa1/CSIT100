**Task 1**: Write a program in the file **minutes.py** that takes as input a number of years and calculates and prints the number of minutes in that period of time. (LO: 2.4)
