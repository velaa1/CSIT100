**Task 1**: Use the round function to modify the program in the file **taxform.py** to display at most two digits of precision in the output number. (LO: 2.4)
