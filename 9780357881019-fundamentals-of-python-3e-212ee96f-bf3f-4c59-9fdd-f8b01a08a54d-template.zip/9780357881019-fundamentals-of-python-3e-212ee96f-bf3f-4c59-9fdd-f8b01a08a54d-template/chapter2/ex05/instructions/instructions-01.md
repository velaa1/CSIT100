**Task 1**: Write a program in the file **momentum.py** that accepts an object’s mass (in kilograms) and velocity (in meters per second) as inputs and then outputs its momentum. (LO: 2.3, 2.4)
