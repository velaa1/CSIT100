**Task 1**: Write the **unique.py** program.
