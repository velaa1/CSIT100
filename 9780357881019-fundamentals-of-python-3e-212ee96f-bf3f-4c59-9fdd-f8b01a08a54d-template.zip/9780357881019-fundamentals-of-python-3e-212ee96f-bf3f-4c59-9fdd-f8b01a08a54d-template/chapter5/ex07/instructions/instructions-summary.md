## Your Tasks

Write a program in the file **unique.py** that inputs a text file. The program should print the unique words in the file in alphabetical order. (LO: 5.1)

## Instructions
