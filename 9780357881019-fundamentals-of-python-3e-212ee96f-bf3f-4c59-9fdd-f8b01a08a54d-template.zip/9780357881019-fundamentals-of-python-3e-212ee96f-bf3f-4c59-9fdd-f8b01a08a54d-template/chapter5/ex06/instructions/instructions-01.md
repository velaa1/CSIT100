**Task 1**: Define the `decimalToRep` function.
