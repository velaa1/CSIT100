## Your Tasks

In the therapist program, when the patient addresses the therapist personally, the therapist’s reply does not change persons appropriately. To see an example of this problem, test the program with “you are not a helpful therapist.” Fix this problem by repairing the dictionary of replacements in the file **doctor.py**. (LO: 5.3)

## Instructions
