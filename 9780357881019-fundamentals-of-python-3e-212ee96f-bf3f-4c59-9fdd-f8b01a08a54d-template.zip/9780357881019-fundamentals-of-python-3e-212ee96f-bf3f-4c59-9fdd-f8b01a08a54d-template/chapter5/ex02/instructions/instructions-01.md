**Task 1**: Write a program in the file **navigate.py** that allows the user to navigate the lines of text in a file.
