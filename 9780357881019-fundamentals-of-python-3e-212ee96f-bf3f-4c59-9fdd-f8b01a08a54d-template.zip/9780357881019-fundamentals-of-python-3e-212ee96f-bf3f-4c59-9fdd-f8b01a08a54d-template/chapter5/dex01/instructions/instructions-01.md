**Task 1**: Modify the **toUpper.py** program so it correctly converts words to uppercase.
