listOfWords = ["Apple", "orange", "banana"]
for word in listOfWords:
    word = word.upper()
print(listOfWords)