**Task 1**: Define the `repToDecimal` function.
