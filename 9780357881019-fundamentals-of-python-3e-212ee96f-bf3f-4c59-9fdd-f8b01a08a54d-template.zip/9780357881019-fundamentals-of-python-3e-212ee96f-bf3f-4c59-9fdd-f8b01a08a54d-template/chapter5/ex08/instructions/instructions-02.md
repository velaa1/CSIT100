Example output:

```
apple 1
banana 3
coconut 5
```
