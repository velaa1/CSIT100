**Task 1**: Write the **concordance.py** program.
