**Task 1**: Define a single new function, `getWords`.
