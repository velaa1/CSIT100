**Task 1**: Make the modifications to the original sentence-generator program in the file **generator.py**.
