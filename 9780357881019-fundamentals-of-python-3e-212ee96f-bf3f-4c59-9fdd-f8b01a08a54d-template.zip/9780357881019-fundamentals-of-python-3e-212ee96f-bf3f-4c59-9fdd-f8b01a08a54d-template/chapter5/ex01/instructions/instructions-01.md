**Task 1**: Define the `mean` function.
