**Task 3**: Define the `median` function.
