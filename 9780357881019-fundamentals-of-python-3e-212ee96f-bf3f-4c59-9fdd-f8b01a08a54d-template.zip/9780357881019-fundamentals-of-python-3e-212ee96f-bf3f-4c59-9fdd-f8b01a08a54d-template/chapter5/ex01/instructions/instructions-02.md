**Task 2**: Define the `mode` function.
