**Task 1**: Modify the therapist program in the file **doctor.py**.
