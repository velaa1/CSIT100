**Task 1**: In **rectangle.py**, enter the program from Figure 1-7 that computes the area of a rectangle.
