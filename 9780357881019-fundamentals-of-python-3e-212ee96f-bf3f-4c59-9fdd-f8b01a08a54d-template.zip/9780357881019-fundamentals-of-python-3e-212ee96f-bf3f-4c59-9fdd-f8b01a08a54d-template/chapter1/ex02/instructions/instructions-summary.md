## Your Tasks

In **rectangle.py**, enter the program from _Figure 1-7_ that computes the area of a rectangle. Run it and correct any errors that occur. Test the program with different inputs. (LO: 1.4)

<p align="center">
<img src="C:\Users\troy\Documents\GitHub\9780357881019-fundamentals-of-python-3e\chapter1\ex02\assets\1.7.png" width="60%" alt="A screenshot of an IDLE windows with a Python script inside it."/>
</p>

## Instructions
