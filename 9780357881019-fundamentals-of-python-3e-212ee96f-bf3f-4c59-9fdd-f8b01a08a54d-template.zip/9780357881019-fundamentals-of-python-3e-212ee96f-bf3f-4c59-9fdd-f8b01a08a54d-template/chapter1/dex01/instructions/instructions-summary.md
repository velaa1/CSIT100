## Your Tasks

Consider the following interaction at the Python shell:

```
>>> first = input("Enter the first integer: ")
Enter the first number: 23
>>> second = input("Enter the second integer: ")
Enter the second number: 44
>>> print("The sum is", first + second)
The sum of the two integers is 2344
```

The expected output is 67, but the output of this computation is 2344. Determine what causes this error and fix it.

## Instructions
