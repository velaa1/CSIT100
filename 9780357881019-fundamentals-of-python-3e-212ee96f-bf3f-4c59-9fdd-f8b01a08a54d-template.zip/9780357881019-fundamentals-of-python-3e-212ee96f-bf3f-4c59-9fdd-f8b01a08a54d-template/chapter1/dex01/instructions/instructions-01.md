**Task 1**: Modify **sum.py** to correct the error.
