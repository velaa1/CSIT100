# Correct the code below.
first = input("Enter the first integer: ")
second = input("Enter the second integer: ")
print("The sum is", first + second)