## Your Tasks

Write a program in **triangle.py** to compute the area of a triangle. Issue the appropriate prompts for the triangle’s base and height. Then, use the formula `.5 * base * height` to compute the area. (LO: 1.4)

## Instructions
