**Task 1**: Write the **triangle.py** program to compute the area of a triangle.
