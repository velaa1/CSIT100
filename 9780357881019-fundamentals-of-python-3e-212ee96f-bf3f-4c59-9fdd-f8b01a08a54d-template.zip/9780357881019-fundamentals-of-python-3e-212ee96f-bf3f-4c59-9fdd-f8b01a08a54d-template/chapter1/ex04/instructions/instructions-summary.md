## Your Tasks

Write a program in **circle.py** that computes the area of a circle. This program should request a number representing a radius as input from the user. It should use the formula `3.14 * radius ** 2` to compute the area and then output this result with the label "square units". (LO: 1.4)

## Instructions
