**Task 1**: Write the **circle.py** program that computes the area of a circle.
