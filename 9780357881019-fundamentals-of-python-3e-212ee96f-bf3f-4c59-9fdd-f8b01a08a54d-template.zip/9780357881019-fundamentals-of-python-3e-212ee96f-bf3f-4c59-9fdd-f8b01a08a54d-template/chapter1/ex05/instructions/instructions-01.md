**Task 1**: Write the **cuboid.py** program that computes and prints the volume of a cuboid, given its height, width, and depth as inputs.
