An example of the program output is shown below:

```txt
Ken Lambert
123 Main Rd, Virginia
123-4567

```
