**Task 1**: Write the **myinfo.py** program.
