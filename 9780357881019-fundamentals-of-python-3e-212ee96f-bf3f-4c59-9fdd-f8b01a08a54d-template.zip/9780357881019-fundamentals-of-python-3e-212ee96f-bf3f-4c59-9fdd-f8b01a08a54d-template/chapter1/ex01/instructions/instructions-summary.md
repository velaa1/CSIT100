## Your Tasks

Write a Python program in a file named **myinfo.py** that prints (displays) your name, address, and telephone number on their own line and in that order. (LO: 1.4)

## Instructions
