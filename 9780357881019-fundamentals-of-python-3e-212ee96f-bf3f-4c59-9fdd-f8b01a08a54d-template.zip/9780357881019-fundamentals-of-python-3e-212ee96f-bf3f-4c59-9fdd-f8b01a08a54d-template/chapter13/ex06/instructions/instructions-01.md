**Task 1**: Modify the recursive Fibonacci function to employ the memoization technique discussed in this chapter.
