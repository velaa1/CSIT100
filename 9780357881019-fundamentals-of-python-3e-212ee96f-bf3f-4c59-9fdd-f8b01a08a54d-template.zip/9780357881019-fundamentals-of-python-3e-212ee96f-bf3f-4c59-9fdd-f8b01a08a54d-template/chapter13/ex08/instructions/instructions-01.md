**Task 1**: State the computational complexity of the `makeRandomList` function using big-O notation and justify your answer.
