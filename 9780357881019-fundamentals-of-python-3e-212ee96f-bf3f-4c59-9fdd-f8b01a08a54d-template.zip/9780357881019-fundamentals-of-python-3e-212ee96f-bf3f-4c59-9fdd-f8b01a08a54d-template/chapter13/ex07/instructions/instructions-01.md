**Task 1**: The function should count the number of recursive calls.
