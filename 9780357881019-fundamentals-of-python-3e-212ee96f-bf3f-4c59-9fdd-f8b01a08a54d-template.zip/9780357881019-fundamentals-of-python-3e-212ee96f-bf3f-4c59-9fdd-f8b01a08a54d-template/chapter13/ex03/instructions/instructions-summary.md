## Your Tasks

Python’s pow function returns the result of raising a number to a given power. Define a function expo (in the file **expo.py**) that performs this task and state its computational complexity using big-O notation. The first argument of this function is the number, and the second argument is the exponent (nonnegative numbers only). You may use either a loop or a recursive function in your implementation. Caution: Do not use Python’s `**` operator or pow function in this exercise! (LO: 13.2)

## Instructions
