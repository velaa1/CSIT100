**Task 1**: Define a function `expo` that returns the result of raising a number to a given power.
