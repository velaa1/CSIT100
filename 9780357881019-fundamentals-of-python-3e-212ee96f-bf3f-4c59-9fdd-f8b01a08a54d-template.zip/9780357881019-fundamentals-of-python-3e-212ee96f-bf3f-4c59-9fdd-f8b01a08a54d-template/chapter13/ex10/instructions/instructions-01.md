**Task 1**: State the computational complexity of the `cCurve` function, in terms of the level, using big-O notation.
