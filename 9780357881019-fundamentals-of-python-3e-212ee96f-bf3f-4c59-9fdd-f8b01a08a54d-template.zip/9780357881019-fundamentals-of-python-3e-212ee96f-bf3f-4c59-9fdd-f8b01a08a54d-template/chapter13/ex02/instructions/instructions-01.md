**Task 1**: Define a function named `reverse` that reverses the elements in its list argument.
