**Task 1**: Define a modified version of the `sequentialSearch` function that halts when the target is less than a given element in the list.
