## Your Tasks

A sequential search of a sorted list can halt when the target is less than a given element in the list. Define a
modified version of the `sequentialSearch` function that uses this algorithm (in the file **search.py**), and state the computational complexity, using big-O notation, of its best-, worst-, and average-case performances.
(LO: 13.2, 13.3)

## Instructions
