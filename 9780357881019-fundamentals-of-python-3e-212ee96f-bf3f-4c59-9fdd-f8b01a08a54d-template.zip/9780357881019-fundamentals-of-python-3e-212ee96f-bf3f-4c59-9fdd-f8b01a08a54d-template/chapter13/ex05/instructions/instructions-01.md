**Task 1**: Modify the `selectionSort` function discussed in this chapter so that it allows the programmer to supply the additional argument to redirect the sort.
