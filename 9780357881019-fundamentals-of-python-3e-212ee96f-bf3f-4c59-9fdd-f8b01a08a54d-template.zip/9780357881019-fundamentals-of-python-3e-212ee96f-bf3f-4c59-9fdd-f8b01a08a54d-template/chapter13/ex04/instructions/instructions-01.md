**Task 1**: Define a recursive function `expo` that uses the recursive strategy.
