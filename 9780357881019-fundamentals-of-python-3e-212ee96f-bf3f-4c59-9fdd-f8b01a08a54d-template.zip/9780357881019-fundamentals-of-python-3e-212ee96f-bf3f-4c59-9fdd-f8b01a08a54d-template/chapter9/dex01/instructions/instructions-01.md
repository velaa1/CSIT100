**Task 1**: Modify the **chessboard.py** program to remove the error.
