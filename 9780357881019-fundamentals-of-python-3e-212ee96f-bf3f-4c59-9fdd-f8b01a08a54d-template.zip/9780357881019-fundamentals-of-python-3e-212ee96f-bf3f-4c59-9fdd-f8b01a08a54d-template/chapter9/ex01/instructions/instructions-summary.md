<!-- manual -->

## Your Tasks

Write a GUI-based program in the file **taxformwithgui.py** that implements the tax calculator program shown in _Figure 9-2_. (LO: 9.2, 9.3, 9.4, 9.5)

<p align="center">
    <img src="../assets/9.2a.png" width="49%" alt="Image 1">
    <img src="../assets/9.2b.png" width="49%" alt="Image 2">
</p>
 <sup>_Figure 9-2_</sup>

## Instructions
