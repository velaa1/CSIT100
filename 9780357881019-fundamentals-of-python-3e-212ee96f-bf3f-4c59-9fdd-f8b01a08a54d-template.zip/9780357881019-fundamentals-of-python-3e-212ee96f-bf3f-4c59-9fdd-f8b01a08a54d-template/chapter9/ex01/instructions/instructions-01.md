**Task 1**: Write the **taxformwithgui.py** GUI program.
