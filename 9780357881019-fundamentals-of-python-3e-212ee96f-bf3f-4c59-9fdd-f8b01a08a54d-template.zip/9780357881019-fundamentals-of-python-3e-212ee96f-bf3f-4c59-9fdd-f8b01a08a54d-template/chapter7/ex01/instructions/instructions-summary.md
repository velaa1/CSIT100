## Your Tasks

Convert Newton’s method for approximating square roots in _Programming Exercise 6.1_ (in the file **newton.py)** to a recursive function named `newton`. (Hint: The estimate of the square root should be passed as a second argument to the function.) (LO: 7.1)

## Instructions

<!--
{
    "CopyExercise": {
        "name": "newton.py",
        "copyTarget": "/chapter6/ex01/student/newton.py",
        "pasteTarget": "/newton.py"
    }
}
-->
