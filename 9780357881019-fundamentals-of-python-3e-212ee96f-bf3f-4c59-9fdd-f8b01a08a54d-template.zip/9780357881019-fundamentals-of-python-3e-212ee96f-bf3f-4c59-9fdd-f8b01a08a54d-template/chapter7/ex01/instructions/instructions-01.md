**Task 1**: Define the recursive function `newton`.
