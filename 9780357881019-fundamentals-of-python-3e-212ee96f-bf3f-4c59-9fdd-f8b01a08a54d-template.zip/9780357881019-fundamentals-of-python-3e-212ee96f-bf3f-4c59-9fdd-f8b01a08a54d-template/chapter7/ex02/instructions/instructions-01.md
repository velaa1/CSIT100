**Task 1**: Implement a recursive strategy for the `newton` method that incorporates the `limitReached` and `improveEstimate` methods.
