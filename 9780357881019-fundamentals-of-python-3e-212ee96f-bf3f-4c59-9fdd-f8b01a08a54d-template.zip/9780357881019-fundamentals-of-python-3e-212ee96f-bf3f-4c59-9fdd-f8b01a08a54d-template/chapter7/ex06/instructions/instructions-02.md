An example of the program is shown below:

```txt
22 81 137
```

```txt
Enter the input file name: numbers.txt
The average is 80.0
```
