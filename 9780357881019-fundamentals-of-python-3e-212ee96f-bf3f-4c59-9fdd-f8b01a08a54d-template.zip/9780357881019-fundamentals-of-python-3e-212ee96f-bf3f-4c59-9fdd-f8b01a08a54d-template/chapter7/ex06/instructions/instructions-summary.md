## Your Tasks

Write a program (in the file **average.py**) that computes and prints the average of the numbers in a text file. You should make use of two higher-order functions to simplify the design. (LO: 7.2)

## Instructions
