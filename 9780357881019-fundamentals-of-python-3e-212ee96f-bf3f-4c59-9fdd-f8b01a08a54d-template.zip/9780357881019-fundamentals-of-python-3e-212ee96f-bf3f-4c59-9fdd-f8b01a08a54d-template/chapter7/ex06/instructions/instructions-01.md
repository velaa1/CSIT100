**Task 1**: Write the **average.py** program so that it computes and prints the average of the numbers in a text file
