## Your Tasks

Add a command to this chapter’s case study program (in the file **filesys.py**) that allows the user to view the contents of a file in the current working directory. When the command is selected, the program should call the function `viewFile` to display a list of filenames and a prompt for the name of the file o be viewed. Be sure to include error recovery. (LO: 7.1)

## Instructions
