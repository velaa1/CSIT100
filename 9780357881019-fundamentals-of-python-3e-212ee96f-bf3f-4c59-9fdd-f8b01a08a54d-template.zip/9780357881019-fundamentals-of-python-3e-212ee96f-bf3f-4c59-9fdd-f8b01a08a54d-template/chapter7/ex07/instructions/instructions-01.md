**Task 1**: Modify the **recognizer.py** program to recognize an arbitrary number of independent clauses recursively.
