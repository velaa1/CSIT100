**Task 1**: Define the `myMap` functions which expect a function of one argument and a list as arguments and return a list of the results.
