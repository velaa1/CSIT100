**Task 3**: Define the `myReduce` function which expects a function of two arguments and a nonempty list as arguments and returns a single value.
