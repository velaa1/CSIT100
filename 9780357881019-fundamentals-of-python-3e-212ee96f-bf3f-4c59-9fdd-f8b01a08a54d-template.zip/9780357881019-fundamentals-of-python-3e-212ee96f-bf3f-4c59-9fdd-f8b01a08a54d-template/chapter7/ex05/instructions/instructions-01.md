**Task 1**: Implement the `printAll` function.
