**Task 1**: Define the `displayFiles` function.
