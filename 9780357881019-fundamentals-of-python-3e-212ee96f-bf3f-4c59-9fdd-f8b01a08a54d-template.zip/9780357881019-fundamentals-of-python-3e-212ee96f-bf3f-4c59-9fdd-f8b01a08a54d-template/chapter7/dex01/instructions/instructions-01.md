**Task 1**: Modify the `nounPhrase` function to fix the `RecursionError`.
