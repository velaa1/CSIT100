def codeEditor():
    #This is the code editor
    print("... and this is the terminal")

codeEditor()