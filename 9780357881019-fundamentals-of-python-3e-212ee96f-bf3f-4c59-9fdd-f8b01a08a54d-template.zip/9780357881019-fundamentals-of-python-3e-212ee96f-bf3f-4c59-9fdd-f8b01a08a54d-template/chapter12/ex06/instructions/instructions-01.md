**Task 1**: Convert the ATM application presented in _Chapter 10_ to a networked application.
