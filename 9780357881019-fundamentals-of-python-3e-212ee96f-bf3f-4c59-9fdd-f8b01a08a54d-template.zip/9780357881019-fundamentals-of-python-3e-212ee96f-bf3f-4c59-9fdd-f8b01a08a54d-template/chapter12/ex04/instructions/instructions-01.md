**Task 1**: Modify the doctor application discussed in this chapter so that it tracks clients by name and history.
