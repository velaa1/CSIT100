**Task 1**: Modify the **server.py** program to correct the error.
