**Task 1**: Consolidate duplicate `add` methods (`SharedTranscript` and `Transcript`) into the `SharedCell` class.
