<!-- manual -->

## Your Tasks

Write the tester program (in the file **readersandwriters.py**) for readers and writers of a shared `Counter` object. A sample run is shown in Figure 12-4. (LO: 12.1, 12.2)

<p align="center">
    <img src="../assets/12.4.png" width="75%" alt="">
</p>
 <sup>Figure 12-4</sup>

## Instructions
