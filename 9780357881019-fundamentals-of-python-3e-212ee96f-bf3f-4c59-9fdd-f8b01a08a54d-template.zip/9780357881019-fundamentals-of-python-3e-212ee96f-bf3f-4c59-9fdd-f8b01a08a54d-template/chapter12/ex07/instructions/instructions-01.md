**Task 1**: Write the tester program (in the file **readersandwriters.py**) for readers and writers of a shared `Counter` object.
