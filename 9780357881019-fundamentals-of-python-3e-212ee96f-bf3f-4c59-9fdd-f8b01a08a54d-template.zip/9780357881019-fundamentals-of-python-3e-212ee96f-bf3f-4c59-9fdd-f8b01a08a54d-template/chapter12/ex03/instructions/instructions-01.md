**Task 1**: Modify the code in the day/time server application (in **timeserver.py**) so that the user on the server side can shut the server down.
