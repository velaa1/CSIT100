**Task 1**: Add synchronization to the ATM program.
