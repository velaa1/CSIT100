<!-- manual -->

## Your Tasks

Redo the producer/consumer program (in the file **pc.py**) so that it allows multiple consumers. Each consumer must be able to consume the same data before the producer produces more data. (LO: 12.1)

## Instructions
