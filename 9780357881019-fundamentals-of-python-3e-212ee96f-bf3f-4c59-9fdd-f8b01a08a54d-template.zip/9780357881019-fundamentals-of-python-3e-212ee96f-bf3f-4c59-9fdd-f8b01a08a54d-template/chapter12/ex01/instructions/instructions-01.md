**Task 1**: Rewrite the **pc.py** program so that it allows multiple consumers.
