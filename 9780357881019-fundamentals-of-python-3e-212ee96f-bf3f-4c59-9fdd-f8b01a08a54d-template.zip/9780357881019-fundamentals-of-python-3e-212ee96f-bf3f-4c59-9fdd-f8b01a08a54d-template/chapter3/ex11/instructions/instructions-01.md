**Task 1**: Write the **sevens.py** program that plays the game of sevens until the pot is empty and prints the number of rolls it took to break the player.
