**Task 1**: Write the **leibniz.py** program that allows the user to specify the number of iterations used in this approximation and that displays the resulting value.
