An example of the program is shown below:

```txt
Enter the number of iterations: 5

The approximation of pi is 3.3396825396825403
```
