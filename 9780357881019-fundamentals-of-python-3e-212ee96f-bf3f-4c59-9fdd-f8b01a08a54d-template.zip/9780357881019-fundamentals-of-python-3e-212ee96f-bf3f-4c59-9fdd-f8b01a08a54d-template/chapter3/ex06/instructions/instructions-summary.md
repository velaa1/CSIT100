## Your Tasks

The German mathematician Gottfried Leibniz developed the following method to approximate the value of **π**: **π**/4 = 1 – 1/3 + 1/5 – 1/7 + . . .

Write a program in the file **leibniz.py** that allows the user to specify the number of iterations used in this approximation and that displays the resulting value. (LO: 3.1)

## Instructions
