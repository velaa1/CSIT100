**Task 1**: Write the **equilateral.py** program that accepts the lengths of three sides of a triangle and indicates whether or not the triangle is an equilateral triangle.
