## Your Tasks

Write a program in the file **equilateral.py** that accepts the lengths of three sides of a triangle as inputs. The program output should indicate whether or not the triangle is an equilateral triangle. (LO: 3.3)

## Instructions
