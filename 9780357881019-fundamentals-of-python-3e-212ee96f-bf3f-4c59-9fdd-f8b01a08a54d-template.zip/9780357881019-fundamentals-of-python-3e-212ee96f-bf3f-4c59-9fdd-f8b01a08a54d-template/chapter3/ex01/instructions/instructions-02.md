An example of the program is shown below:

```txt
Enter the first side: 5
Enter the second side: 5
Enter the third side: 5
The triangle is equilateral.
```
