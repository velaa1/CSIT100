An example of the program is shown below:

```txt
Enter the height from which the ball is dropped: 25
Enter the bounciness index of the ball: .5
Enter the number of times the ball is allowed to continue bouncing: 3

Total distance traveled is: 65.625 units.
```
