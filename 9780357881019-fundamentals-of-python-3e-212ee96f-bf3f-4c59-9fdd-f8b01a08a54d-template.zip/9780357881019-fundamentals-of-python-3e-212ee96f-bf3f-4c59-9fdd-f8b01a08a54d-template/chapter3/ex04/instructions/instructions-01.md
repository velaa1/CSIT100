**Task 1**: Write the **bouncy.py** program calculates the total distance traveled by the ball.
