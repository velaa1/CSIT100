An example of the program is shown below:

```txt
Enter the smaller number: 5
Enter the larger number: 15

The greatest common divisor is 5
```
