**Task 1**: Write the **gcd.py** program that lets the user enter two integers and then prints each step in the process of using the Euclidean algorithm to find their GCD.
