## Your Tasks

Modify the guessing-game program of Section 3.5 in the file **guess.py** so that the user thinks of a number that the computer must guess. The computer must make no more than the minimum number of guesses, and it must prevent the user from cheating by entering misleading hints.

> _Hint_: Use the `math.log` function to compute the minimum number of guesses needed after the lower and upper bounds are entered. (LO: 3.3, 3.4)

## Instructions
