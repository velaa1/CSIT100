**Task 1**: Modify the guessing-game program of Section 3.5 in the file **guess.py** so that the user thinks of a number that the computer must guess.
