An example of the program is shown below:

```txt
Enter the initial number of organisms: 10
Enter the rate of growth [a real number > 1]: 2
Enter the number of hours to achieve the rate of growth: 2
Enter the total hours of growth: 6

The total population is 80
```
