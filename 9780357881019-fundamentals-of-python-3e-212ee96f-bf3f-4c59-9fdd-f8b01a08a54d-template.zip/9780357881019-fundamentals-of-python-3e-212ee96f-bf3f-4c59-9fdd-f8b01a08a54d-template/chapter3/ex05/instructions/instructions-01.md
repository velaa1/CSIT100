**Task 1**: Write a program in the file **population.py** that takes these inputs and displays a prediction of the total population.
