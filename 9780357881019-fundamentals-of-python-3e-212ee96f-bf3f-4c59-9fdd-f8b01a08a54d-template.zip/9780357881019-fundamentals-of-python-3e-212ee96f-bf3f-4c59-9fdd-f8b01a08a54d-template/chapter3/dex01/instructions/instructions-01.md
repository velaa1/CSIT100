**Task 1**: Modify **computeAverage.py** to correct the error.
