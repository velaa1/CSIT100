## Your Tasks

Jack has written a program that computes and prints the average of 10 test scores. The program prompts the user for each input score. Here is the code for this program:

```python
count = 1
while count < 10:
score = int(input("Enter test score number " + str(count) + ": ")
total = total + score
count = count + 1
average = total / count
print("The average test score is", average)
```

This program contains errors. Determine what type of error this is, describe how it is detected, and correct it.

## Instructions
