**Task 1**: Write the **sum.py** program that accepts numerical user input and prints the sum of the numbers and their average.
