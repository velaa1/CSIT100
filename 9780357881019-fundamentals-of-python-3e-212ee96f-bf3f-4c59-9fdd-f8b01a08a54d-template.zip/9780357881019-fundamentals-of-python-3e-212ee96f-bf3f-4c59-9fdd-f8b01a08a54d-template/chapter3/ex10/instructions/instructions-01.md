**Task 1**: Write the **tidbit.py** program that displays the correct table information.
