# Write your program here
print('Hello')