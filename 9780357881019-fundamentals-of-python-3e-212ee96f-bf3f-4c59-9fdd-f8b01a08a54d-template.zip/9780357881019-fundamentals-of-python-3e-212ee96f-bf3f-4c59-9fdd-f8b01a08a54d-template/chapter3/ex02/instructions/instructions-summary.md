## Your Tasks

Write a program in the file **right.py** that accepts the lengths of three sides of a triangle as inputs. The program output should indicate whether or not the triangle is a right triangle.

Recall from the Pythagorean theorem that in a right triangle, the square of one side equals the sum of the squares of the other two sides. (LO: 3.3)

## Instructions
