An example of the program is shown below:

```txt
Enter the first side: 6
Enter the second side: 8
Enter the third side: 10

The triangle is a right triangle.
```
