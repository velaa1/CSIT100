**Task 1**: Write the **right.py** program that accepts the lengths of three sides of a triangle and indicates whether or not the triangle is a right triangle.
