**Task 1**: Write the **salary.py** program that displays a salary schedule, in tabular format, for teachers in a school district.
