**Task 1**: Write a script that uses several instances of the different shape classes to draw a house and a stick figure.
