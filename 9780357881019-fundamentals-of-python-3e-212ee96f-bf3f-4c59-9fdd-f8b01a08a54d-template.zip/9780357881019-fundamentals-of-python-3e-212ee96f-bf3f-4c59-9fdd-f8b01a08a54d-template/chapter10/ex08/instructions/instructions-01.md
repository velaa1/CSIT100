**Task 1**: Add `faceup` instance variable to the `Card` class.
