**Task 2**: Add `turn` method to `Card` class.
