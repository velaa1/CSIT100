An example of the program is shown below:

```
A new deck, cards face down:
Ace of Spades False
2 of Spades False
3 of Spades False
...
...
...
Jack of Spades False
Queen of Spades False
King of Spades False
Ace of Diamonds False
2 of Diamonds False
3 of Diamonds False
...
...
...
A deck shuffled once, cards face up:
9 of Diamonds True
6 of Clubs True
King of Clubs True
King of Hearts True
3 of Spades True
...
```
