Add the `isWinner` and `isLoser` methods to the `Player` class.
