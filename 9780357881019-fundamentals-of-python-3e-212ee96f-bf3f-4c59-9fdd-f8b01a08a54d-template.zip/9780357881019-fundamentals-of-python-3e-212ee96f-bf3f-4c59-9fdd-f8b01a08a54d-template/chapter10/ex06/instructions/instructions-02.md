**Task 2**: Add `getNumberOfRolls` method to `Player` class.
