An example of the program is show below:

```txt
(2, 2) total = 4
(1, 2) total = 3
(2, 3) total = 5
(3, 3) total = 6
(1, 6) total = 7
You lose!
Enter the number of games: 10
The total number of wins is 5
The total number of losses is 5
The average number of rolls per win is 1.80
The average number of rolls per loss is 4.20
The winning percentage is 0.500
```
