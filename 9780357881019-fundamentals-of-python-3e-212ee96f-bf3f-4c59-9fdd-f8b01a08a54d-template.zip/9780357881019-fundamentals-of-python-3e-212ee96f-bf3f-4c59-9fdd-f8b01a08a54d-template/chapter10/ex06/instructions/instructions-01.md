**Task 1**: Add `rollDice` method to `Player` class.
