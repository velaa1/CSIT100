**Task 1**: The program displays a popup message that the police will be called after a user has had three successive failures.
