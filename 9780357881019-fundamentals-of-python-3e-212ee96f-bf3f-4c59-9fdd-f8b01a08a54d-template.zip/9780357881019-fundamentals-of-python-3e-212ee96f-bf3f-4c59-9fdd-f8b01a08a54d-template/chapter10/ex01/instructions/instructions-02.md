**Task 2**: Add method to test for less than (`__lt__`).
