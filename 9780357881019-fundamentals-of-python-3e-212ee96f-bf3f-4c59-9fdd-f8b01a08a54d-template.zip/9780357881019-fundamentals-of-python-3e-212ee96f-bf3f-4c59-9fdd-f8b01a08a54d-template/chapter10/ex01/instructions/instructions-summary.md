## Your Tasks

Add three methods to the `Student` class that compare two` Student` objects. One method (`__eq__`) should test for equality. A second method (`__lt__`) should test for less than. The third method (`__ge__`) should test for greater than or equal to. In each case, the method returns the result of the comparison of the two students’ names. Include a main function that tests all of the comparison operators.

Note: The program should output in the following format:

```
False: False
True: True
True: True
False: False
True: True
True: True
True: True
True: True
True: True
True: True
```

(LO: 10.2)

## Instructions
