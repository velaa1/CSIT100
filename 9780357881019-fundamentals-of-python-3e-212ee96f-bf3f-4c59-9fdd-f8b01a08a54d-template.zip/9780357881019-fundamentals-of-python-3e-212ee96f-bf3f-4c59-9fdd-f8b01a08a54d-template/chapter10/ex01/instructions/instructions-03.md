**Task 3**: Add method to test for greater than or equal to (`__ge__`).
