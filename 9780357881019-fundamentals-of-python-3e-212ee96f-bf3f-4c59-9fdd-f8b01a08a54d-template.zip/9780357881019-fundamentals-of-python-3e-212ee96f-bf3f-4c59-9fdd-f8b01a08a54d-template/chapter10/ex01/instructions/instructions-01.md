**Task 1**: Add a method to test for equality (`__eq__`).
