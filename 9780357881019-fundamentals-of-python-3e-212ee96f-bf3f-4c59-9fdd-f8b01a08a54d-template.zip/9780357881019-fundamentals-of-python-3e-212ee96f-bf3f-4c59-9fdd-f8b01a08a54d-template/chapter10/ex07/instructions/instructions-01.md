**Task 1**: Roll dice test.
