**Task 1**: Use `shuffle` method from random module to shuffle list. Use `sort` list method to sort list Output unsorted and sorted list to terminal.
