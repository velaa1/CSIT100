**Task 1**: Modify `__str__` method to return accounts ordered by name.
