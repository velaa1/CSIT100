An example of the program is shown below:

```
Hello, how can I help you today?
> I am sick
You seem to think that you are sick?
> Yes
And what do you think about this?
> I am not feeling good
Did I just hear you say that you are not feeling good?
> Yes
Why do you believe that Yes?
> My nose is running
I would like to hear more about that.
> I have a headache too
You seem to think that you have a headache too?
> Correct
Go on.
> It doesn't stop
Did I just hear you say that It doesn't stop?
> Correct
Go on.
> That's it
And what do you think about this?
> quit
Have a nice day!
```
