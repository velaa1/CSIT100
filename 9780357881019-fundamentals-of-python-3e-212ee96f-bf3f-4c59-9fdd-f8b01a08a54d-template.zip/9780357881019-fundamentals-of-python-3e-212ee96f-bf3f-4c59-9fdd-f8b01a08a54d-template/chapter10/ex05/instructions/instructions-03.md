**Task 2**: Add the `reply` method to the `Doctor` class.
