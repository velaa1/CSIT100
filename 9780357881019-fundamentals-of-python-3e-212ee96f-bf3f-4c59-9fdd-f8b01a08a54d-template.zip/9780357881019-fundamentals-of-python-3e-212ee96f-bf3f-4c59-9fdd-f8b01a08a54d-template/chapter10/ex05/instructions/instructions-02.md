**Task 2**: Add the `farewell` method to the `Doctor` class.
