**Task 1**: Add the `greeting` method to the `Doctor` class.
