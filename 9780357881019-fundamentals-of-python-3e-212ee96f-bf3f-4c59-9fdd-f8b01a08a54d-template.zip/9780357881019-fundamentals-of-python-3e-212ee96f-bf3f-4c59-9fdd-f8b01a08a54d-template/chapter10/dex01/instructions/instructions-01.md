**Task 1**: Modify the **student.py** program to remove the `ZeroDivisionError`.
