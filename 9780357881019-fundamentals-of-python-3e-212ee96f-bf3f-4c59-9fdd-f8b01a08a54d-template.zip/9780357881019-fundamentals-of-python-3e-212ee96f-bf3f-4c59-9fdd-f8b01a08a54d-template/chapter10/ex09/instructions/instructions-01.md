**Task 1**: Write a GUI program that allows you to deal and view cards from a deck.
