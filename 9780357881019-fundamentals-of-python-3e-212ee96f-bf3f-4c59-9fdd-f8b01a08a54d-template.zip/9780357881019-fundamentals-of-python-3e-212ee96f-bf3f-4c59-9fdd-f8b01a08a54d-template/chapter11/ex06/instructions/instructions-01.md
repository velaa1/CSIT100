**Task 1**: Define the `cleanStats`function.
