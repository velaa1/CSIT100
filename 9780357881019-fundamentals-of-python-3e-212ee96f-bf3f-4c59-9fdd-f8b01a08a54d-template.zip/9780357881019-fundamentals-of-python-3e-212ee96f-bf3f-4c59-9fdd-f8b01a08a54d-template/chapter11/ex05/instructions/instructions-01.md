**Task 1**: Write the **breadprice.py** program so it displays a line plot of the average price for each year in the table.
