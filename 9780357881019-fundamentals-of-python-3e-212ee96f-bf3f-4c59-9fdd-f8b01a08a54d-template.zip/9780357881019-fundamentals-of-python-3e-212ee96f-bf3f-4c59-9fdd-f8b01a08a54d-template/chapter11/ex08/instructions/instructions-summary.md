<!-- manual -->

## Your Tasks

Add a line plot feature to the program of the _Analyzing Basketball Statistics_ case study. When the user selects a radio button, the data for a column are analyzed and the program displays the results as before, but the program also pops up a line plot of the selected column of data. The line plot’s y-axis should be labeled with the name of the column heading. (LO: 11.2, 11.3)

<!--
{
    "CopyExercise": {
        "name": "11.7 program files",
        "copyTarget": "/chapter11/ex07/student/*",
        "pasteTarget": "/"
    }
}
-->

## Instructions
