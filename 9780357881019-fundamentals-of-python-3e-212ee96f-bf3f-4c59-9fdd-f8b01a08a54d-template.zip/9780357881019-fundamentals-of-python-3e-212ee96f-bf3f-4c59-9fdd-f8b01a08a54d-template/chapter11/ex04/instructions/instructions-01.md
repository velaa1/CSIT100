**Task 1**: Write the **histogram.py** program.
