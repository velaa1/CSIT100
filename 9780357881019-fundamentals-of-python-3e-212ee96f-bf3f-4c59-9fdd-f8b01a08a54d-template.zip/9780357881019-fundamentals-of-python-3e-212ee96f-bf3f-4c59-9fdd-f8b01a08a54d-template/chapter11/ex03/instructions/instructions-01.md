**Task 1**: Add a command button named "Plot scores" to the user interface that displays a line plot of the student’s test scores.
