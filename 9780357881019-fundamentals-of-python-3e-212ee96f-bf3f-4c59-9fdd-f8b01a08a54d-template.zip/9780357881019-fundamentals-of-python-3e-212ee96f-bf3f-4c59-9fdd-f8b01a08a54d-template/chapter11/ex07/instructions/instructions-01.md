**Task 1**: Add radio buttons for the remaining columns of data to the program window.
