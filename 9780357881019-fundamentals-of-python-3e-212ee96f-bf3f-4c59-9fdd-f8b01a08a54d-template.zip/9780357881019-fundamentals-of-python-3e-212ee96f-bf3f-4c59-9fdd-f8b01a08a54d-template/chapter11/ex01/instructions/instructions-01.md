**Task 1**: Complete the implementation of the `Student` class.
