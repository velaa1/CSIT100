<!-- manual -->

## Your Tasks

Complete the implementation of the `Student` class from the _Analyzing Student Test Scores_ case study. Include a short tester program in a file named **studenttest.py** that exercises the new methods. (LO: 11.1)

## Instructions
