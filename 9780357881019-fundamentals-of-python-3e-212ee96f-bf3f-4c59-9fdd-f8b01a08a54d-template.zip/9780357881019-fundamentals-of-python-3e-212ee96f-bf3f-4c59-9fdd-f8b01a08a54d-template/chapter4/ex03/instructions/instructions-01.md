**Task 1**: Modify encrypt and decrypt scripts to encrypt and decrypt entire files of text.
