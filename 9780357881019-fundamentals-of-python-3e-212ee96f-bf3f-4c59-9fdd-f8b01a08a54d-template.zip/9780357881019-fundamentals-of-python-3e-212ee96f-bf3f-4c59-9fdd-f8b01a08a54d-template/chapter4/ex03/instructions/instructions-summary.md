## Your Tasks

Modify the scripts of _Programming Exercises 1_ and _Programming Exercise 2_ to encrypt and decrypt entire files of text. (LO: 4.1, 4.5)

## Instructions
