**Task 1**: Modify the **textAnalysis.py** program to fix the syllable count.
