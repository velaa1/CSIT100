## Your Tasks

Jack just completed the program for the Flesch text analysis from this chapter’s case study. His supervisor, Jill, has discovered an error in his code. The error causes the program to count a syllable containing consecutive vowels as multiple syllables. Suggest a solution to this problem in Jack’s code and modify the program so that it handles these
cases correctly.

## Instructions
