**Task 1**: Define the`invert` function.
