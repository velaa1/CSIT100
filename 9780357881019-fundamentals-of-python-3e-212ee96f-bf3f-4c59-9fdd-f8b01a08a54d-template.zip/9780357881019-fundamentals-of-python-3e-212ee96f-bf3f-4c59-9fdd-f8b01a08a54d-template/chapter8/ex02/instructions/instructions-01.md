**Task 1**: Modify the **ccurve.py** program so that it draws the line segments using random colors.
