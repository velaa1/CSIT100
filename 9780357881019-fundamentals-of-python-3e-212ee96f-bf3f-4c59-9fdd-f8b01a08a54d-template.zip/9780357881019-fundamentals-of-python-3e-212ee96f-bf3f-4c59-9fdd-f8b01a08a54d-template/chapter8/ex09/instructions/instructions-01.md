**Task 1**: Develop the `lighten`, `darken`, and `colorFilter` functions.
