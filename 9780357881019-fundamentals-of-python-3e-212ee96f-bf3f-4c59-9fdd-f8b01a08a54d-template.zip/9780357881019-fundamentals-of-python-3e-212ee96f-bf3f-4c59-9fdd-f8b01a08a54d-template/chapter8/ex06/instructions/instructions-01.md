**Task 1**: Define a second version of the `grayscale` function.
