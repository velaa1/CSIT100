<!-- manual -->

## Your Tasks

Define a second version of the `grayscale` function (in the file **grayscale.py**) that uses the allegedly crude method of simply averaging each RGB value. Test the function by comparing its results with those of the other version discussed in this chapter. (LO: 8.2)

## Instructions
