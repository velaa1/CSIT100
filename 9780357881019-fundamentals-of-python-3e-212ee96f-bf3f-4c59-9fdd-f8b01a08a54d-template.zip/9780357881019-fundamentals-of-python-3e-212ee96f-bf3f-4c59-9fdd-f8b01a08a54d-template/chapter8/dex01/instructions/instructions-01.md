**Task 1**: Modify the **randomart.py** program to remove the `TclError`.
