**Task 1**: Design, implement, and test the **mondrian.py** script that uses a recursive function to draw the patterns.
