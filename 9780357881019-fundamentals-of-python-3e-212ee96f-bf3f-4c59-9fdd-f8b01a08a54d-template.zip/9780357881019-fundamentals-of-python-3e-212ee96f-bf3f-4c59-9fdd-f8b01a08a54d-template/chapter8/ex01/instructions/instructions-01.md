**Task 1**: Define the `drawCircle` function so that it draws the specified circle.
