<!-- manual -->

## Your Tasks

Define a function `drawCircle` (in the file **circle.py**). This function should expect a `Turtle` object, the coordinates of the circle’s center point, and the circle’s radius as arguments. The function should draw the specified circle. The algorithm should draw the circle’s circumference by turning 3 degrees and moving a given distance 120 times. Calculate the distance moved with the formula: 2.0* π* _radius_ / 120.0. (LO: 8.1)

## Instructions
