**Task 1**: Write and test a function named `sepia`.
