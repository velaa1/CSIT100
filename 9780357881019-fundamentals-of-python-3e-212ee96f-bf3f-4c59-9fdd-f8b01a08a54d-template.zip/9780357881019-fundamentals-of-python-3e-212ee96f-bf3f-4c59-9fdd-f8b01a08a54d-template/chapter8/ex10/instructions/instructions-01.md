**Task 1**: Define the `sharpen` function.
