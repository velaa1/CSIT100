**Task 1**: Write the **koch.py** script that draws the Koch snowflake.
