**Task 1**: Define the `posterize` function in the **posterize.py** script so that it converts a color image to two-colors.
